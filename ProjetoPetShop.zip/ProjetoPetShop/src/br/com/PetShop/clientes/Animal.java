package br.com.PetShop.clientes;

public class Animal  {

	//Atributos
	private String nome;
	private String nomeDoTutor;
	private int idade;
	private String tipoDeAnimal;
	private String numeroDeContato;
	private String cpfTutor;
	private int precoConsultaCao = 80;
	private int precoConsultaGato = 70;
	
	//Contrutor
	public Animal(String nome, String nomeDoTutor, int idade, String tipoDeAnimal,String numeroDeContato,String cpfTutor) {
		super();
		this.nome = nome;
		this.nomeDoTutor = nomeDoTutor;
		this.idade = idade;
		this.tipoDeAnimal = tipoDeAnimal;
		this.numeroDeContato = numeroDeContato;
		this.cpfTutor = cpfTutor;
	}
	
	//Encaplsulamento
	public String getNome() {		
		return nome;
	}
	
	public String getNomeTutor() {	
		return nomeDoTutor;
	}
	
	public int getIdade() {
		return idade;
	}
	
	public String getTipoDeAnimal() {
		return tipoDeAnimal;
	}
	
	public void setNome(String nome) {		
		this.nome = nome;
	}
	
	public void setNomeTutor(String nomeDoTutor) {	
		this.nomeDoTutor = nomeDoTutor;
	}
	
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	public void setTipoDeAnimal(String tipoDeAnimal) {
		this.tipoDeAnimal = tipoDeAnimal;
	}
	
		public String getNumeroDeContato() {
		return numeroDeContato;
	}

	public void setNumeroDeContato(String numeroDeContato) {
		this.numeroDeContato = numeroDeContato;
	}		
	
	public String getCpfTutor() {
		return cpfTutor;
	}

	public void setCpfTutor(String cpfTutor) {
		this.cpfTutor = cpfTutor;
	}
	
	public int getPrecoConsultaCao() {
		return precoConsultaCao;
	}

	public void setPrecoConsultaCao(int precoConsultaCao) {
		this.precoConsultaCao = precoConsultaCao;
	}	
	
	public int getPrecoConsultaGato() {
		return precoConsultaGato;
	}

	public void setPrecoConsultaGato(int precoConsultaGato) {
		this.precoConsultaGato = precoConsultaGato;
	}
	
	//Métodos
	public void MostrarInfo (){
		System.out.println("Nome do Animal: " + nome);
		System.out.println("Nome do Tutor: " + nomeDoTutor);
		System.out.println("Idade: " + idade);
		System.out.println("Tipo de pelo do cachorro: " + tipoDeAnimal);
	}
	
	public void marcarConsulta(String dataDaConsulta , String numeroDeContato,  String horarioDaConsulta , String veterinarioResponsavel) {
		System.out.println("Consulta remarcada para " + nomeDoTutor + " " + cpfTutor + "\n----------------------------------------------------------------------------------------------------");
		System.out.println("Data da consulta: " + dataDaConsulta);
		System.out.println("Horário da consulta: " + horarioDaConsulta);
		System.out.println("Veterinario Resposavel: " + veterinarioResponsavel);
		if(tipoDeAnimal == "gato" || tipoDeAnimal == "Gato") {
			System.out.println("Valor Total: " + precoConsultaGato);
		} else{
			System.out.println("Valor Total: " + precoConsultaCao);
		}
		
	}
	
	








}
