package br.com.PetShop.clientes;

public class Cachorro extends Animal {
	
	//Atributos
	private String tipoDePelo;
	private String raca;
	private String porteDoCachorro;
	
	//Contrutor
	public Cachorro(String nome, String nomeDoTutor, int idade, String tipoDeAnimal, String numeroDeContato,String cpfTutor, String tipoDePelo, String raca, String porteDoCachorro) {
		super(nome, nomeDoTutor, idade, tipoDeAnimal, numeroDeContato, cpfTutor);
		this.tipoDePelo = tipoDePelo;
		this.raca = raca;
		this.porteDoCachorro = porteDoCachorro;
	}
	
	
	//Encapsulamento
	public String getTipoDePelo() {
		return tipoDePelo;
	}
	
	public String getRaca() {
		return raca;
	}
	
	public String getPorteDoCachorro() {
		return porteDoCachorro;
	}
	
	public void setTipoDePelo(String tipoDePelo) {
		this.tipoDePelo = tipoDePelo;
	}
	
	public void setRaca(String raca) {
		this.raca = raca;
	}
	
	public void setPorteDoCachorro(String porteDoCachorro) {
		this.porteDoCachorro = porteDoCachorro;
	}


	@Override
	public void MostrarInfo() {
		super.MostrarInfo();
		System.out.println("Tipo de Pelo: " + tipoDePelo);
		System.out.println("Raça: " + raca);
		System.out.println("Porte do Cachorro: " + porteDoCachorro);
	}



	
	
	
	
	
	
	
	
	

	
	
}
