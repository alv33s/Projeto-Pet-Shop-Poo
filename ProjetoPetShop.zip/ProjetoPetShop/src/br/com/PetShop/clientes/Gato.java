package br.com.PetShop.clientes;

public class Gato extends Animal {

	//Atributos
	private String raca;
	private String tamanhoDaUnha;
	
	//contrutor
	public Gato(String nome, String nomeDoTutor, int idade, String tipoDeAnimal, String numeroDeContato, String cpfTutor, String raca, String tamanhoDaUnha) {
		super(nome, nomeDoTutor, idade, tipoDeAnimal, numeroDeContato, cpfTutor);
		this.raca = raca;
		this.tamanhoDaUnha = tamanhoDaUnha;
	}
	
	//encapsulamento
	public String getRaca() {
		return raca;
	}
	
	public String getTamanhoUnha() {
		return tamanhoDaUnha;
	}
	
	public void setRaca(String raca) {
		this.raca = raca;
	}
	
	
	public void setTamanhoUnha(String tamanhoDaUnha) {
		this.tamanhoDaUnha = tamanhoDaUnha;
	}

	@Override
	public void MostrarInfo() {
		super.MostrarInfo();
		System.out.println("Raça: " + raca);
		System.out.println("Tamanho da Unha: " + tamanhoDaUnha);
		
	}
	

	
	
	

	
	
	
	
}
