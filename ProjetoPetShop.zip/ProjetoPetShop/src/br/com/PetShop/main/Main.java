package br.com.PetShop.main;

import br.com.PetShop.clientes.*;

public class Main {
	
	public static void main(String[] args ) {
		
		Animal c1 = new Cachorro("Belinha", "Pedro", 4, "Cachorro", "061 9876-7887", "071-936-722-19", "Curto", "Salsicha", "Pequeno");
		c1.marcarConsulta("27/04" ,"061 9875-8986", "13:40" , "João");
		System.out.println(c1.getNumeroDeContato());
		c1.MostrarInfo();
		
		
		
		Animal c2 = new Gato("\nAlfredo","Junior", 3, "Gato", "061 7470-6312",  "968-238-951-82 ","Dom Sphynx", "médio");
		c2.marcarConsulta("15/04", "061 7470-6312", "16:00", "Ranielson");
		System.out.println(c2.getCpfTutor());
		c2.MostrarInfo();
		
		
		
	}
	
}
